// Sticky nav active link handling (basic)
(function() {
  const links = document.querySelectorAll('#mainNav a');
  const path = window.location.pathname.split('/').pop() || 'index.html';
  links.forEach(a => {
    const href = a.getAttribute('href').split('/').pop();
    if (href === path) a.style.background = 'rgba(255,255,255,0.2)';
  });
})(); 
