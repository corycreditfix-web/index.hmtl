
# Cory's Credit Repair – Starter Website

This zip contains a simple, multi-page site with:

- Sticky top navigation and mascot/logo at the top
- Home, Pricing, About, Contact, and Thank You pages
- Contact form wired to Formspree (update your form ID)
- SEO meta tags + JSON-LD + `sitemap.xml` and `robots.txt`
- Simple, clean styling with navy/gold/white

## How to use

1) **Open `index.html`** to preview locally (double-click).
2) **Upload to GitHub Pages** or any static host (Netlify, Vercel, Cloudflare Pages).
3) **Update your domain** inside `sitemap.xml` and `<link rel="canonical">` tags (currently set to `https://example.com`).  
4) **Contact Form Email:**  
   - Create a free Formspree form at https://formspree.io/ and get your form ID (looks like `f/abcdwxyz`).  
   - In `contact.html`, replace `action="https://formspree.io/f/your_form_id"` with your actual Formspree action URL.  
   - Optionally set the form `action` to redirect to `/thank-you.html` after submission (Formspree dashboard setting).
5) **Favicon/Branding:** Replace `assets/img/logo.png` with your real mascot/logo (same file name to avoid code changes).

## File structure

- index.html, about.html, pricing.html, contact.html, thank-you.html
- assets/css/styles.css
- assets/js/main.js
- assets/img/logo.png
- sitemap.xml, robots.txt
